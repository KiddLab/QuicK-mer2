from setuptools import setup

setup(name='qm2_human_rarity',
      version='0.1.0',
      packages=['human_extension_project'])
